#! /bin/bash

g++ reformat.cpp -o reformat -std=c++11

